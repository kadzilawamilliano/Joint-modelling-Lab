# Motor Insurance Research Lab (Streamlit)

A GitHub-ready Streamlit app for exploratory data cleaning, policy non-renewal construction, and predictor screening for the research:

**Joint Modelling of Motor Insurance Claim Costs and Policy Non-Renewal Using Shared Random Effects**

## Features

- Upload a motor insurance CSV (semicolon-separated source files are supported).
- Review schema, missingness, duplicates, numeric summaries, and date ranges.
- Audit annual claim costs, including zero and negative values.
- Construct a **provisional same-ID policy non-renewal indicator** using the scheduled renewal date and a user-set observation cutoff.
- Flag date mismatches rather than silently labelling them.
- Compare the provisional outcome with `Lapse` as a diagnostic only.
- Review candidate predictors, potential leakage, timing questions, and numeric redundancy.
- Download parsed data and a dataset with the provisional outcome and audit flags.

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

## Deploy using GitHub + Streamlit Community Cloud

1. Create a GitHub repository (for example, `motor-insurance-research-lab`).
2. Upload `app.py`, `requirements.txt`, and `README.md` from this project.
3. Open Streamlit Community Cloud and sign in with GitHub.
4. Select **Create app**, choose your repository, branch, and `app.py`.
5. Deploy. The app will install packages from `requirements.txt`.
6. Open the deployed app URL and upload the dataset from your computer.

The dataset is not embedded in this repository. This is intentional: it avoids publishing your research data in a public repository. If the dataset has sharing restrictions, keep it private and only upload it to a deployment whose access settings are appropriate.

## Important research caveats

- The default cutoff is **31 December 2018**, a provisional setting that must be confirmed against the dataset documentation.
- The outcome means **no renewal observed under the same ID by the cutoff**. It does not prove that the person left the insurer; a replacement or another product may have a different ID.
- `Lapse` is an aggregate count and is not used as the target.
- `Value_vehicle` is flagged as a potential future-information leakage variable because it is documented as a 31 December 2019 valuation.
- `N_claims_year` is flagged because it is generally not available at the start of the same claim-cost year.
- `N_claims_history`, `R_Claims_history`, policy counts, and premium require a careful check of when the values would be known.
- The app performs screening and audit only. It does not automatically select a statistically optimal model or fit the shared-random-effect model.

## Suggested next development step

After reviewing the audit outputs, add model-fitting and evaluation pages with a defensible time-based train/test split, appropriate Tweedie and logistic models, and then a shared-random-effect model if the available Python libraries and data structure support the intended specification.
